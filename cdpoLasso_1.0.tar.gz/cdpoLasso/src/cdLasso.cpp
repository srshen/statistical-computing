#include <RcppArmadillo.h>

//[[Rcpp::depends(RcppArmadillo)]]

using namespace Rcpp;
using namespace arma;

//' using coordinate descent algorithm for LASSO
//'
//' @param X the design matrix
//' @param Y the response variable
//' @param beta_real the real beta we use to generate data Y
//' @param lambda the tunning parameter of penalty
//' @return the list of parameters, l1_difference, and residuals
//[[Rcpp::export]]
Rcpp::List cdLasso(const arma::mat& X, const arma::mat& Y, const arma::colvec& beta_real, const double lambda);
double soft_threshold(const double lambda, const double zz);

// coordinate descent algorithm for Lasso
Rcpp::List cdLasso(const arma::mat& X, const arma::mat& Y, const arma::colvec& beta_real, const double lambda){
    
    int itermax = 1200;       // maximum number of iteration
    int ncol = X.n_cols;     // dimension p
    int nrow = X.n_rows;     // n
    arma::colvec beta = ones(ncol);
    arma::colvec res = Y - X * beta;
    arma::colvec beta0 = beta;

    arma::colvec diff_l1 = zeros(itermax);
    for(int count=1;count <= itermax; count++){
        for(int p = 1; p <= ncol; p++){
            beta0(p-1) = soft_threshold(lambda, beta(p-1)+dot(res,X.col(p-1))/nrow);
            res = res + X.col(p-1)*(beta(p-1) - beta0(p-1));
        }
        beta = beta0;
        diff_l1(count-1) = sum(abs(beta_real - beta));
    }
    
    
    
    
    return List::create(Named("parameters") = beta,
                        Named("l1_difference")  = diff_l1,
                        Named("residual")   = res);
}


// soft thresholding function is correct
double soft_threshold(const double lambda, const double zz){
    double value = 1,maxx;
    if(zz > 0) value = 1;
    else if(zz == 0.0) value = 0;  //ridiculous!
    else value = -1;
    
    if (abs(zz) - lambda < 0.0) maxx = 0.0;
    else maxx = abs(zz) - lambda;
    value = value * maxx;
    
    return value;
}
