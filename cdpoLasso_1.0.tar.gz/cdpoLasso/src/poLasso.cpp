#include <RcppArmadillo.h>

//[[Rcpp::depends(RcppArmadillo)]]

using namespace Rcpp;
using namespace arma;

//' using proximal operator algorithm for LASSO
//'
//' @param X the design matrix
//' @param Y the response variable
//' @param beta_real the real beta we use to generate data Y
//' @param lambda the tunning parameter of penalty
//' @return the list of parameters, l1_difference, and residuals
//[[Rcpp::export]]
Rcpp::List poLasso(const arma::mat& X, const arma::mat& Y, const arma::vec& beta_real, const double lambda);
double soft_threshold1(const double lambda, const double zz);

// proximal operator algorithm for Lasso
Rcpp::List poLasso(const arma::mat& X, const arma::mat& Y, const arma::vec& beta_real, const double lambda){
    int itermax = 1200;
    int ncol = X.n_cols;   //dimension p
    int nrow = X.n_rows;   // n
    arma::vec eigval;
    arma::mat eigvec;
    eig_sym(eigval,eigvec, X.t() * X/nrow);
    double Mvalue = eigval(ncol-1);  //thresholding value M
    arma::vec beta  = ones(X.n_cols);
    arma::vec beta0 = beta;
    arma::vec diff_l1 = zeros(itermax);
    
    arma::vec XYB   = X.t()*(Y - X*beta)/(Mvalue*nrow);  //initial value
    
    for(int count=1; count <= itermax; count++){    //number of iteration
        for(int p = 1; p<=ncol; p++){
            beta0(p-1) = soft_threshold1(lambda/Mvalue,beta(p-1)+XYB(p-1));
        }
        beta = beta0;
        XYB = X.t()*(Y - X*beta)/(Mvalue*nrow);
        diff_l1(count-1) = sum(abs(beta_real - beta));
    }
    
    return List::create(Named("parameters")   = beta,
                        Named("l1_difference") = diff_l1);
}


// soft thresholding function is correct
double soft_threshold1(const double lambda, const double zz){
  double value = 1,maxx;
  if(zz > 0) value = 1;
  else if(zz == 0.0) value = 0;  //ridiculous!
  else value = -1;
  
  if (abs(zz) - lambda < 0.0) maxx = 0.0;
  else maxx = abs(zz) - lambda;
  value = value * maxx;
  
  return value;
}
